//By momo™
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <algorithm>
#include "kmeans.h"
#include "linear.h"
using namespace std;

// Used for km_clusterID() in further calling,
// User may call another kmeans, for another kmean-clustering
// To avoid memory leak, we will check if global_K is -1 or not
static int global_K = -1;
static int feat_num;

static double **centers;
static double *cnorm; // 2-Norm^2 for each Center

static void create_centers(problem pb, int K, int cluster[], int cnum[]){
	for(int k = 0; k < K; k++){
		cnorm[k] = 0;
		for(int d = 0; d < pb.n; d++)
			centers[k][d] = 0;
	}

	for(int i = 0; i < pb.l; i++){
		int k = cluster[i];
		
		for(int j = 0; pb.x[i][j].index != -1; j++){
			int idx = pb.x[i][j].index;
			double val = pb.x[i][j].value;
			
			cnorm[k] -= centers[k][idx-1] * centers[k][idx-1];
			centers[k][idx-1] += val / cnum[k];
			cnorm[k] += centers[k][idx-1] * centers[k][idx-1];
		}
	}
}

static void resolve_empty_cluster(int L, int K, int *cluster, int *cnum){
	for(int k = 0; k < K; k++){
		while(cnum[k] == 0){
			int i = rand() % L;
			if(cnum[cluster[i]] > 1){
				cnum[k] ++;
				cnum[cluster[i]] --;
				
				cluster[i] = k;
			}
		}
	}
}

int km_clusterID(feature_node x[]){
    int closestK = 0;
    double bestdis = 1e200;
    
    for(int k = 0; k < global_K; k++){
        double inn_prod = 0;
        for(int i = 0; x[i].index != -1; i++){
            int idx = x[i].index;
            double val = x[i].value;
            
            if(idx <= feat_num)
                inn_prod += centers[k][idx-1] * val;
        }
        
        if(bestdis > cnorm[k] - 2 * inn_prod){
            bestdis = cnorm[k] - 2 * inn_prod;
            closestK = k;
        }
    }
    return closestK;
}

void kmeans(problem pb, int K, int MXITER){
	srand((unsigned int)clock());
    
    // Initialize Global Stuffs
	if(global_K != -1){
		for(int i = 0; i < global_K; i++)
			free(centers[i]);
		free(centers);
		free(cnorm);
	}

    global_K = K;
    feat_num = pb.n;

    centers = (double**)malloc(sizeof(double*) * (size_t)K);
    for(int i = 0; i < K; i++) centers[i] = (double*)malloc(sizeof(double) * (size_t)pb.n);

    cnorm = (double*)malloc(sizeof(double) * (size_t)K); // 2-norm^2 of each center
	
    // Initialize Local Stuffs
	int *cluster, *cnum;

	cluster = (int*)malloc(sizeof(int) * (size_t)pb.l); // which cluster a point belongs to
	cnum = (int*)malloc(sizeof(int) * (size_t)K); // number of points in a cluster

	/*
	// Random Clustering
    for(int i = 0; i < K; i++) cnum[i] = 0;
	for(int i = 0; i < pb.l; i++){
		cluster[i] = rand() % K;
		cnum[cluster[i]] ++;
	}
	
	// Resolve Empty Cluster
	resolve_empty_cluster(pb.l, K, cluster, cnum);
    
	// Create Centers
	create_centers(pb, K, cluster, cnum);
	*/

	for(int k = 0; k < K; k++){
		cnorm[k] = 0;
		for(int d = 0; d < pb.n; d++)
			centers[k][d] = 0;
	}

	for(int k = 0; k < K; k++){
		int i = rand() % pb.l;
		for(int j = 0; pb.x[i][j].index != -1; j++){
			int idx = pb.x[i][j].index;
			double val = pb.x[i][j].value;
			centers[k][idx-1] = val;
			cnorm[k] += val * val;
		}
	}
    
	for(int T = 0; T < MXITER; T++){
		// Clustering
		for(int k = 0; k < K; k++)
			cnum[k] = 0;
        for(int i = 0; i < pb.l; i++){
            cluster[i] = km_clusterID(pb.x[i]);
            cnum[cluster[i]] ++;
        }
		
		// Resolve Empty Cluster
		resolve_empty_cluster(pb.l, K, cluster, cnum);
        
		// Create Centers
		create_centers(pb, K, cluster, cnum);
	}
  
	/*
    printf("-->> Final Centers: <<--\n");
    for(int i = 0; i < global_K; i++){
        for(int j = 0; j < feat_num; j++){
			if(centers[i][j] > 1e-5)
	            printf("%d:%f ", j+1, centers[i][j]);
        }
        printf("\n\n");
    }
	*/

	free(cluster);
	free(cnum);
}
