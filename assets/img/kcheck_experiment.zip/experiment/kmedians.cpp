//By momo™
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <vector>
#include <algorithm>
#include "kmedians.h"
#include "linear.h"
using namespace std;

// Used for kmd_clusterID() in further calling,
// User may call another kmedian, for another kmedian-clustering
// To avoid memory leak, we will check if global_K is -1 or not
static int global_K = -1;
static int feat_num;

static double **centers;
static double *cnorm; // 1-Norm for each Center

double abs_f(double x){
	if(x < 0) return -x;
	return x;
}

static void create_centers(problem pb, int K, int cluster[], int cnum[]){
	vector<double> *store = new vector<double>[K * pb.n];

	for(int i = 0; i < pb.l; i++){
		int k = cluster[i];
		
		for(int j = 0; pb.x[i][j].index != -1; j++){
			int idx = pb.x[i][j].index;
			double val = pb.x[i][j].value;
			
			store[k * pb.n + idx - 1].push_back(val);
		}
	}

	for(int k = 0; k < K; k++){
		cnorm[k] = 0;
		for(int d = 0; d < pb.n; d++){
			if(store[k*pb.n+d].size() == 0){
				centers[k][d] = 0;
				continue;
			}
			sort(store[k*pb.n+d].begin(), store[k*pb.n+d].end());
			centers[k][d] = store[k*pb.n+d][store[k*pb.n+d].size() / 2];
			cnorm[k] += abs_f(centers[k][d]);
		}
	}

	delete [] store;
}

static void resolve_empty_cluster(int L, int K, int *cluster, int *cnum){
	for(int k = 0; k < K; k++){
		while(cnum[k] == 0){
			int i = rand() % L;
			if(cnum[cluster[i]] > 1){
				cnum[k] ++;
				cnum[cluster[i]] --;
				
				cluster[i] = k;
			}
		}
	}
}

int kmd_clusterID(feature_node x[]){
    int closestK = 0;
    double bestdis = 1e200;
    
    for(int k = 0; k < global_K; k++){
        double inn_val = 0;
        for(int i = 0; x[i].index != -1; i++){
            int idx = x[i].index;
            double val = x[i].value;
            
            if(idx <= feat_num){
                inn_val += abs_f(centers[k][idx-1] - val);
				inn_val -= abs_f(centers[k][idx-1]);
			}
        }
        
        if(bestdis > cnorm[k] + inn_val){
            bestdis = cnorm[k] + inn_val;
            closestK = k;
        }
    }
    return closestK;
}

void kmedians(problem pb, int K, int MXITER){
	srand((unsigned int)clock());
    
    // Initialize Global Stuffs
	if(global_K != -1){
		for(int i = 0; i < global_K; i++)
			free(centers[i]);
		free(centers);
		free(cnorm);
	}

    global_K = K;
    feat_num = pb.n;

    centers = (double**)malloc(sizeof(double*) * (size_t)K);
    for(int i = 0; i < K; i++) centers[i] = (double*)malloc(sizeof(double) * (size_t)pb.n);

    cnorm = (double*)malloc(sizeof(double) * (size_t)K); // 1-norm of each center
	
    // Initialize Local Stuffs
	int *cluster, *cnum;

	cluster = (int*)malloc(sizeof(int) * (size_t)pb.l); // which cluster a point belongs to
	cnum = (int*)malloc(sizeof(int) * (size_t)K); // number of points in a cluster

	// Random Clustering
    for(int k = 0; k < K; k++) cnum[k] = 0;
	for(int i = 0; i < pb.l; i++){
		cluster[i] = rand() % K;
		cnum[cluster[i]] ++;
	}
	
	// Resolve Empty Cluster
	resolve_empty_cluster(pb.l, K, cluster, cnum);
    
	// Create Centers
	create_centers(pb, K, cluster, cnum);
    
	for(int T = 0; T < MXITER; T++){
		// Clustering
		for(int k = 0; k < K; k++)
			cnum[k] = 0;
        for(int i = 0; i < pb.l; i++){
            cluster[i] = kmd_clusterID(pb.x[i]);
            cnum[cluster[i]] ++;
        }
		
		// Resolve Empty Cluster
		resolve_empty_cluster(pb.l, K, cluster, cnum);

		// Create Centers
		create_centers(pb, K, cluster, cnum);
	}
  
	/*
    printf("-->> Final Centers: <<--\n");
    for(int i = 0; i < global_K; i++){
        for(int j = 0; j < feat_num; j++){
            printf("%d:%f ", j+1, centers[i][j]);
        }
        printf("\n\n");
    }
	*/

	free(cluster);
	free(cnum);
}
