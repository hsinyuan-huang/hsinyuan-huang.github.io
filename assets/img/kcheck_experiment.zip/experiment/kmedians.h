#ifndef _KMEDIANS_H_
#define _KMEDIANS_H_
#include "linear.h"
void kmedians(problem pb, int K, int MXITER);
int kmd_clusterID(feature_node vec[]);
#endif
