#! /usr/bin/python
from sys import argv
import os.path

if len(argv) != 2:
    print "Usage: python train_val.py FILENAME"
    exit(-1)

fpath = argv[1]
fname = "transformed_data/" + os.path.basename(fpath)

data = open(argv[1], "r")
data_tr = open(fname+".tr", "w")
data_val = open(fname+".val", "w")

import random

for line in data:
    if random.randint(0,3) != 0:
        data_tr.write(line)
    else:
        data_val.write(line)
