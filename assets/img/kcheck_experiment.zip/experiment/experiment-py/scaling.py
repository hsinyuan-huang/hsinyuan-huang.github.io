#! /usr/bin/python
from sys import argv
import os.path
import subprocess
import os

if len(argv) != 2:
    print "Usage: ./scaling.py data"
    exit(-1)

fpath = argv[1]
fname = os.path.basename(fpath)

fnorm_fpath = "transformed_data/" + fname + ".f"
inorm_fpath = "transformed_data/" + fname + ".i"

#===============================

if os.path.exists("log_files/" + fname + ".log"):
    y = raw_input("Log File Existed. Do you want to proceed? (press y) ")
    if y != 'y':
        print "Aborted."
        exit(-1)
output = open("log_files/" + fname + ".log", "w", 0)

subprocess.call("../featurewise " + fpath + " " + fnorm_fpath, shell=True)
subprocess.call("../instancewise " + fpath + " " + inorm_fpath, shell=True)

# Below are changeable
eps = "1e-4"
for log3_C in range(-12, 13):
    output.write("log3_C = " + str(log3_C) + "\n")
    def run_one(f):
        start = os.times()[2]
        subprocess.call("../liblinear-2.1/train -s 2 -e "+eps+" -c "\
                        + str(3**log3_C) + " -v 5 -q " + f, shell=True,\
                        stdout=output)
        output.write(str(os.times()[2] - start) + "\n")
    run_one(fpath)
    run_one(fnorm_fpath)
    run_one(inorm_fpath)
