#! /usr/bin/python
from sys import argv
import os.path
import subprocess

if len(argv) != 2:
    print "Usage: python runML.py FILENAME"
    exit(-1)

fpath = argv[1]
fname = os.path.basename(fpath)

if os.path.exists("log_files/" + fname + ".klog"):
    ans = raw_input("Log file exists: Do you proceed? (Press y) ")
    if ans != "y":
        print "Terminated."
        exit(-1)

if not os.path.exists("transformed_data/" + fname + ".f.val"):
    subprocess.call("../featurewise " + fpath + " " + "transformed_data/" + fname + ".f", shell=True)
    subprocess.call("./train_val.py " + "transformed_data/" + fname + ".f", shell=True)
    
output = open("log_files/" + fname + ".klog", "w", 0)

for K in [2, 4, 6, 8, 16, 25, 40, 60, 80, 100, 150]:
    output.write("K = " + str(K) + "\n")
    for T in range(5):
        start = os.times()[2]
        subprocess.call("../nksvm 0 " + str(K) + " -1 -1 " + "transformed_data/" + fname + ".f.tr"
                        + " " + "transformed_data/" + fname + ".f.val",\
                        shell=True, stdout=output)
        output.write(str(os.times()[2] - start) + "\n")
