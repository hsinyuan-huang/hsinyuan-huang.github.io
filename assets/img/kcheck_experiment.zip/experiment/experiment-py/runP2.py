#! /usr/bin/python
from sys import argv
import os.path
import subprocess

if len(argv) != 2:
    print "Usage: python runP2.py data"
    exit(-1)

fpath = argv[1]
fname = os.path.basename(fpath)

if os.path.exists("log_files/" + fname + ".p2log"):
    ans = raw_input("Log file exists: Do you proceed? (Press y) ")
    if ans != "y":
        print "Aborted."
        exit(-1)

if not os.path.exists("transformed_data/" + fname + ".f.val"):
    subprocess.call("../featurewise " + fpath + " " + "transformed_data/" +  fname + ".f", shell=True)
    subprocess.call("./train_val.py " + "transformed_data/" + fname + ".f", shell=True)
    
output = open("log_files/" + fname + ".p2log", "w", 0)

for coef0 in [0.01, 0.1, 1, 10, 100]:
    output.write("coef0 = " + str(coef0) + "\n")
    start = os.times()[2]
    subprocess.call("../p2svm " + str(coef0) + " " + "transformed_data/" + fname+".f.tr"
                    + " " + "transformed_data/" + fname+".f.val",\
                    shell=True, stdout=output)
    output.write(str(os.times()[2] - start) + "\n")
