//By momo™
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <errno.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include "linear.h"

#include "kmedians.h"
#include "kmeans.h"
#include "skmeans.h"

#define Malloc(type,n) (type *)malloc(((size_t)n)*sizeof(type))
using namespace std;

int cTYPE;
double bias = -1;

void cluster(problem prob, int K, int MXITER){
	if(cTYPE == 0) kmeans(prob, K, MXITER);
	else if(cTYPE == 1) skmeans(prob, K, MXITER);
	else if(cTYPE == 2) kmedians(prob, K, MXITER);
	else{
		fprintf(stderr, "clusterTYPE invalid\n");
		exit(-1);
	}
}

int clusterID(feature_node *x){
	if(cTYPE == 0) return km_clusterID(x);
	else if(cTYPE == 1) return skm_clusterID(x);
	else if(cTYPE == 2) return kmd_clusterID(x);
	else{
		fprintf(stderr, "clusterTYPE invalid\n");
		exit(-1);
	}
}

void print_null(const char* s){ }
void exit_input_error(int line_num)
{
	fprintf(stderr,"Wrong input format at line %d\n", line_num);
	exit(1);
}
problem read_problem(const char *filename, int max_n);

void print_nksvm_usage_and_exit(){
	fprintf(stderr, "Usage: ./executable clusterTYPE clusterNUM MXITER bias train_file predict_file\n");
	fprintf(stderr, "clusterTYPE: 0(Kmeans), 1(SKmeans), 2(Kmedians)\n");
	fprintf(stderr, "clusterNUM: -1 for auto-choosing\n");
	fprintf(stderr, "MXITER: max iteration for clustering, -1 for auto-choosing\n");
	fprintf(stderr, "bias: -1 for no bias term\n");
	exit(-1);
}

int main(int argc, char **argv){
	setbuf(stdout, NULL);

#ifdef NKSVM
	if(argc != 7) print_nksvm_usage_and_exit();

	cTYPE = atoi(argv[1]);
	if(cTYPE == 0) fprintf(stderr, "Cluster Type: Kmeans\n");
	else if(cTYPE == 1) fprintf(stderr, "Cluster Type: SKmeans\n");
	else if(cTYPE == 2) fprintf(stderr, "Cluster Type: Kmedians\n");
	else print_nksvm_usage_and_exit();

	bias = atof(argv[4]);

	problem train_prob = read_problem(argv[5], -1);
	problem predi_prob = read_problem(argv[6], train_prob.n);
#elif defined(SVM)
	if(argc != 4){
		fprintf(stderr, "Usage: ./executable bias train_file predict_file\n");
		fprintf(stderr, "bias: -1 for no bias term\n");
		exit(-1);
	}
	
	bias = atof(argv[1]);

	problem train_prob = read_problem(argv[2], -1);
	problem predi_prob = read_problem(argv[3], train_prob.n);
#else
	if(argc != 4){
		fprintf(stderr, "Usage: ./executable coef0 train_file predict_file\n");
		fprintf(stderr, "Kernel Function: (x_i^T x_j + coef0)^2\n");
		fprintf(stderr, "coef0 = 1 is recommended\n");
		exit(-1);
	}
	problem train_prob = read_problem(argv[2], -1);
	problem predi_prob = read_problem(argv[3], train_prob.n);
#endif

#ifdef NKSVM
	int K = atoi(argv[2]);
	int MXITER = atoi(argv[3]);

	if(K == -1){
		K = max((int)(5 * log(train_prob.l)), 4);
		fprintf(stderr, "Using Cluster # = %d (Auto)\n", K);
	}

	if(MXITER == -1){
		MXITER = 15;
		fprintf(stderr, "Using MXITER = 15\n");
	}

	problem *subprob = Malloc(problem, K);
	model **submodel = Malloc(model*, K);

	cluster(train_prob, K, MXITER);

	for(int k = 0; k < K; k++){
		subprob[k].l = 0;
		subprob[k].n = train_prob.n;
		subprob[k].bias = bias;
	}
	for(int i = 0; i < train_prob.l; i++)
		subprob[clusterID(train_prob.x[i])].l++;

	int *cnt;
	cnt = Malloc(int, K);

	for(int k = 0; k < K; k++){
		cnt[k] = 0;
		subprob[k].x = Malloc(feature_node*, subprob[k].l);
		subprob[k].y = Malloc(double, subprob[k].l);
	}

	for(int i = 0; i < train_prob.l; i++){
		int k = clusterID(train_prob.x[i]);
		subprob[k].x[cnt[k]] = train_prob.x[i];
		subprob[k].y[cnt[k]] = train_prob.y[i];
		cnt[k]++;
	}
#endif

	parameter def_param;
	def_param.solver_type = L2R_L2LOSS_SVC;
	def_param.C = 1;
	def_param.eps = 1e-4;
	def_param.p = 0.1;
	def_param.nr_weight = 0;
	def_param.weight_label = NULL;
	def_param.weight = NULL;
	def_param.init_sol = NULL;
#ifdef POLY2
	def_param.coef0 = atof(argv[1]);
	def_param.gamma = 1.0;
#endif

	set_print_string_function(&print_null);

	int correct;
	double best_C, best_rate;
	model *model; model = NULL;

#ifdef NKSVM
	// K-means SVM
	fprintf(stderr, "Start Finding Parameter C for NKSVM\n");

	for(int k = 0; k < K; k++){
		if(subprob[k].l == 1) continue;
		find_parameter_C(&subprob[k], &def_param, 5, -1, 1024, &best_C, &best_rate);

		def_param.C = best_C;
		submodel[k] = train(&subprob[k], &def_param);
	}

	correct = 0;
	for(int i = 0; i < predi_prob.l; i++){
		int k = clusterID(predi_prob.x[i]);
		double y;

		if(subprob[k].l == 1) y = subprob[k].y[0];
		else y = predict(submodel[k], predi_prob.x[i]);

		if(y == predi_prob.y[i]){
			correct ++;
		}
	}
	printf("Testing Accuracy on NKSVM: %f%%\n", 100.0 * correct / predi_prob.l);
#endif

#ifdef SVM
	// Normal Linear SVM
	fprintf(stderr, "Start Finding Parameter C for SVM\n");
	
	find_parameter_C(&train_prob, &def_param, 5, -1, 1024, &best_C, &best_rate);
	printf("Best C = %g, with Cross Validation Accuracy  =  %g%%\n", best_C, best_rate*100.);

	def_param.C = best_C;
	model = train(&train_prob, &def_param);

	correct = 0;
	for(int i = 0; i < predi_prob.l; i++){
		double y = predict(model, predi_prob.x[i]);

		if(y == predi_prob.y[i]){
			correct ++;
		}
	}
	printf("Testing Accuracy on SVM: %f%%\n", 100.0 * correct / predi_prob.l);
#endif

#ifdef POLY2
	// Poly2 SVM
	fprintf(stderr, "Start Finding Parameter C for p2SVM\n");
	find_parameter_C(&train_prob, &def_param, 5, -1, 1024, &best_C, &best_rate);

	//fprintf(stderr, "For Whole Data\n");
	printf("Best C = %g, with Cross Validation Accuracy =  %g%%\n", best_C, best_rate*100.);

	def_param.C = best_C;
	model = train(&train_prob, &def_param);

	correct = 0;
	for(int i = 0; i < predi_prob.l; i++){
		double y = predict(model, predi_prob.x[i]);

		if(y == predi_prob.y[i]){
			correct ++;
		}
	}
	printf("Testing Accuracy on p2SVM: %f%%\n", 100.0 * correct / predi_prob.l);
#endif
}

/* Below are from LIBLINEAR */

static char *line = NULL;
static int max_line_len;

static char* readline(FILE *input)
{
	int len;

	if(fgets(line,max_line_len,input) == NULL)
		return NULL;

	while(strrchr(line,'\n') == NULL)
	{
		max_line_len *= 2;
		line = (char *) realloc(line,(size_t)max_line_len);
		len = (int) strlen(line);
		if(fgets(line+len,max_line_len-len,input) == NULL)
			break;
	}
	return line;
}

struct feature_node *x_space;

// read in a problem (in libsvm format)
// When max_n >= 0, it means the maximum featute size is set to max_n
problem read_problem(const char *filename, int max_n)
{
	problem prob;
	int max_index, inst_max_index, i;
	size_t elements, j;
	FILE *fp = fopen(filename,"r");
	char *endptr;
	char *idx, *val, *label;

	if(fp == NULL)
	{
		fprintf(stderr,"can't open input file %s\n",filename);
		exit(1);
	}

	prob.l = 0;
	elements = 0;
	max_line_len = 1024;
	line = Malloc(char,max_line_len);
	while(readline(fp)!=NULL)
	{
		char *p = strtok(line," \t"); // label

		// features
		while(1)
		{
			p = strtok(NULL," \t");
			if(p == NULL || *p == '\n') // check '\n' as ' ' may be after the last feature
				break;
			elements++;
		}
		elements++; // for bias term
		prob.l++;
	}
	rewind(fp);

	prob.bias=bias;

	prob.y = Malloc(double,prob.l);
	prob.x = Malloc(struct feature_node *,prob.l);
	x_space = Malloc(struct feature_node,elements+prob.l);

	max_index = 0;
	j=0;
	for(i=0;i<prob.l;i++)
	{
		inst_max_index = 0; // strtol gives 0 if wrong format
		readline(fp);
		prob.x[i] = &x_space[j];
		label = strtok(line," \t\n");
		if(label == NULL) // empty line
			exit_input_error(i+1);

		prob.y[i] = strtod(label,&endptr);
		if(endptr == label || *endptr != '\0')
			exit_input_error(i+1);

		while(1)
		{
			idx = strtok(NULL,":");
			val = strtok(NULL," \t");

			if(val == NULL)
				break;

			errno = 0;
			x_space[j].index = (int) strtol(idx,&endptr,10);
			if(endptr == idx || errno != 0 || *endptr != '\0' || x_space[j].index <= inst_max_index)
				exit_input_error(i+1);
			else if(max_n >= 0 && x_space[j].index > (prob.bias > 0? max_n - 1: max_n))
				break;
			else
				inst_max_index = x_space[j].index;

			errno = 0;
			x_space[j].value = strtod(val,&endptr);
			if(endptr == val || errno != 0 || (*endptr != '\0' && !isspace(*endptr)))
				exit_input_error(i+1);

			++j;
		}

		if(inst_max_index > max_index)
			max_index = inst_max_index;

		if(prob.bias > 0)
			x_space[j++].value = prob.bias;

		x_space[j++].index = -1;
	}

	if(max_n >= 0){
		prob.n = max_n;
		if(prob.bias >= 0){
			for(i=1;i<prob.l;i++)
				(prob.x[i]-2)->index = max_n;
			x_space[j-2].index = max_n;
		}
	}
	else{
		if(prob.bias > 0)
		{
			prob.n=max_index+1;
			for(i=1;i<prob.l;i++)
				(prob.x[i]-2)->index = prob.n;
			x_space[j-2].index = prob.n;
		}
		else
			prob.n=max_index;
	}

	fclose(fp);
	return prob;
}
