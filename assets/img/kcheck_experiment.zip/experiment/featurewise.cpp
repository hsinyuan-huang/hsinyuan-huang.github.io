//By momo™
#include <stdio.h>
#include <math.h>
#include <unistd.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <string.h>
#include <algorithm>
#define MXBUF 10000000
using namespace std;

FILE *input, *output;
char buf[MXBUF], *tok[MXBUF];

int **X1;
double **X2;
double *Y;

int featnum = 0;
double *featmax;

int main (int argc, char* argv[]){
	if(argc != 3){
		fprintf(stderr, "Usage: ./featurewise data scaled-data\n");
		exit(-1);
	}

	if((input = fopen(argv[1], "r")) == NULL){
		fprintf(stderr, "Open input fail\n");
		exit(-1);
	}

	if((output = fopen(argv[2], "w")) == NULL){
		fprintf(stderr, "Open output fail\n");
		exit(-1);
	}

	int instNUM = 0;
	while(fgets(buf, MXBUF, input)) instNUM ++;

	X1 = (int**)malloc(sizeof(int*) * (instNUM + 10));
	X2 = (double**)malloc(sizeof(double*) * (instNUM + 10));
	Y = (double*)malloc(sizeof(double) * (instNUM + 10));

	rewind(input);

	int NUM = 0;
	while(fgets(buf, MXBUF, input)){
		tok[0] = strtok(buf, ": \t\n");
		Y[NUM] = atof(tok[0]);
		
		int cnt = 0;
		while((tok[cnt] = strtok(NULL, ": \t\n")) != NULL){
			if(tok[cnt][0] == 0) continue;
			cnt ++;
		}

		X1[NUM] = (int*)malloc(sizeof(int) * (cnt / 2 + 1));
		X2[NUM] = (double*)malloc(sizeof(double) * (cnt / 2 + 1));
		
		for(int i = 0; i < cnt; i += 2){
			X1[NUM][i/2] = atoi(tok[i]);
			X2[NUM][i/2] = atof(tok[i + 1]);

			featnum = max(X1[NUM][i/2], featnum);
		}
		X1[NUM][cnt / 2] = -1;

		NUM ++;
	}

	printf("Read in all Datas: number of instances = %d (feat num = %d)\n", NUM, featnum);

	featmax = (double*)malloc(sizeof(double) * (featnum + 1));
	for(int i = 0; i <= featnum; i++) featmax[i] = 0;

	for(int i = 0; i < NUM; i++){
		for(int j = 0; ; j++){
			if(X1[i][j] == -1) break;
			featmax[X1[i][j]] = max(featmax[X1[i][j]], fabs(X2[i][j]));
		}
	}

	for(int i = 0; i < NUM; i++){
		fprintf(output, "%g ", Y[i]);

		for(int j = 0; ; j++){
			if(X1[i][j] == -1) break;
			if(featmax[X1[i][j]] == 0) featmax[X1[i][j]] = 1;
			
			fprintf(output, "%d:%g ", X1[i][j], X2[i][j] / featmax[X1[i][j]]);
		}
		fprintf(output, "\n");
	}
}
