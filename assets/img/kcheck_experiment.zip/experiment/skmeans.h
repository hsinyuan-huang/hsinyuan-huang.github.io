#ifndef _SKMEANS_H_
#define _SKMEANS_H_
#include "linear.h"
void skmeans(problem pb, int K, int MXITER);
int skm_clusterID(feature_node vec[]);
#endif
