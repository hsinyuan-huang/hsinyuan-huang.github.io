#ifndef _KMEANS_H_
#define _KMEANS_H_
#include "linear.h"
void kmeans(problem pb, int K, int MXITER);
int km_clusterID(feature_node vec[]);
#endif
