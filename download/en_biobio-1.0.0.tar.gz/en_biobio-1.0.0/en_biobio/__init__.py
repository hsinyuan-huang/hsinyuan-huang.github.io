# coding: utf8
from __future__ import unicode_literals

from pathlib import Path
from spacy.util import load_model_from_init_py, get_model_meta

from spacy.tokens import Doc, Span
from spacy.language import Language
from spacy.pipeline import TextCategorizer

__version__ = get_model_meta(Path(__file__).parent)['version']

class PicoTextcat(TextCategorizer):

    def __init__(self, doc):
        TextCategorizer.__init__(self, doc.vocab)
        self.name = 'pico_textcat'
        self._pico_cats = 'pico_cats'
        Doc.set_extension(self._pico_cats, default=list(), force=True)
        Span.set_extension(self._pico_cats, default=dict(), force=True)
        assert(Doc.has_extension(self._pico_cats))

    def __call__(self, doc):
        sent_docs = [sent.as_doc() for sent in doc.sents]
        scores, tensors = self.predict(sent_docs)

        all_pico_scores = []
        for i, sent in enumerate(doc.sents):
            sent_pico_cats = dict()
            for j, label in enumerate(self.labels):
                sent_pico_cats[label] = float(scores[i, j])
            all_pico_scores.append(sent_pico_cats)
            sent._.pico_cats = sent_pico_cats
        doc._.pico_cats = all_pico_scores
        return doc

def ner_aggregate(doc):
    doc._._tmp_ents = doc._._tmp_ents + list(doc.ents)
    doc.ents = []
    return doc

def ner_finalize(doc):
    doc.ents = doc._._tmp_ents
    return doc

def load(**overrides):
    Doc.set_extension('_tmp_ents', default=[], force=True)

    Language.factories['ner_bc5cdr'] = Language.factories['ner']
    Language.factories['aggre_bc5cdr'] = lambda nlp, **cfg: ner_aggregate
    Language.factories['ner_chemdner'] = Language.factories['ner']
    Language.factories['aggre_chemdner'] = lambda nlp, **cfg: ner_aggregate
    Language.factories['ner_msh'] = Language.factories['ner']
    Language.factories['aggre_msh'] = lambda nlp, **cfg: ner_aggregate
    Language.factories['finalize_ner'] = lambda nlp, **cfg: ner_finalize
    Language.factories['pico_textcat'] = lambda nlp, **cfg: PicoTextcat(nlp, **cfg)
    
    return load_model_from_init_py(__file__, **overrides)